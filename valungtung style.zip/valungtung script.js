let yesSize = 1.5; // Starts at normal size

function moveButton() {
    const noBtn = document.getElementById('noBtn');
    const yesBtn = document.getElementById('yesBtn');

    // 1. Get the screen width and height
    // We subtract 150px so the button doesn't go off the edge
    const maxWidth = window.innerWidth - 150;
    const maxHeight = window.innerHeight - 150;

    // 2. Calculate a random X and Y position
    const randomX = Math.floor(Math.random() * maxWidth);
    const randomY = Math.floor(Math.random() * maxHeight);

    // 3. Apply the new position
    // "fixed" means it floats relative to the screen, ignoring the window box
    noBtn.style.position = 'fixed'; 
    noBtn.style.left = randomX + 'px';
    noBtn.style.top = randomY + 'px';

    // 4. Make the YES button grow slightly
    yesSize += 0.2;
    yesBtn.style.transform = `scale(${yesSize})`;
}

function celebrate() {
    // Change the text
    document.getElementById('question').innerText = "YAY! I LOVE YOU! 💖";
    
    // Change the image to a happy hugging gif
    document.getElementById('main-gif').src = "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExOHpueGZ3bmZqZ3RreHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4JnB0PWEmZXA9djFfaW50ZXJuYWxfZ2lmX2J5X2lkJmN0PWc/UMon0WU1m6UK4/giphy.gif"; 
    
    // Hide the No button
    document.getElementById('noBtn').style.display = 'none';
}